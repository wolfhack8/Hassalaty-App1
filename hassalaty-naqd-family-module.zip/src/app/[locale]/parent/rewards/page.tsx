import { setRequestLocale } from "next-intl/server";
import { requireParent } from "@/server/family/require-family";
import { listPendingRedemptions, ensureDefaultRewards } from "@/server/family/reward-actions";
import { PageTitle } from "@/features/admin/ui";
import { ParentRewardsManager, localizedRewardTitle, type PendingRedemptionRow } from "@/features/family/parent-rewards-manager";
import { pick, loc } from "@/lib/localized";
import type { Locale } from "@/i18n/routing";

export const dynamic = "force-dynamic";

export default async function ParentRewardsPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const lo = locale as Locale;
  const parent = await requireParent(locale);

  await ensureDefaultRewards();
  const pending = await listPendingRedemptions(parent.familyId);

  const rows: PendingRedemptionRow[] = pending.map((r) => ({
    id: r.id,
    pointsCost: r.pointsCost,
    requestedAt: r.requestedAt.toISOString(),
    childName: pick(
      r.user.name && typeof r.user.name === "object" && "en" in r.user.name
        ? (r.user.name as { en: string; ar: string })
        : loc("Child", "الابن"),
      lo,
    ),
    rewardTitle: localizedRewardTitle(r.reward.title, lo, loc("Reward", "مكافأة")),
  }));

  return (
    <div>
      <PageTitle
        title={lo === "ar" ? "إدارة المكافآت" : "Manage rewards"}
        subtitle={
          lo === "ar"
            ? "وافق على طلبات أبنائك وأضف مكافآت مخصصة لعائلتك."
            : "Approve your children's requests and add custom family rewards."
        }
      />
      <ParentRewardsManager locale={lo} initialPending={rows} />
    </div>
  );
}
