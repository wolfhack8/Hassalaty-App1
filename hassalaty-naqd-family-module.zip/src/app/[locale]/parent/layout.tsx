import type { Metadata } from "next";
import { setRequestLocale } from "next-intl/server";
import { pick } from "@/lib/localized";
import type { Locale } from "@/i18n/routing";
import { requireParent } from "@/server/family/require-family";
import { getFamilyOverview } from "@/server/family/get-family-context";
import { FamilyShell } from "@/features/family/family-shell";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Family Console · Hassalaty",
  robots: { index: false, follow: false },
};

export default async function ParentLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale);
  const parent = await requireParent(locale);

  const overview = await getFamilyOverview(parent.familyId);
  const familyName = overview ? pick(overview.family.name, locale as Locale) : "Family";

  return (
    <FamilyShell variant="parent" title={familyName}>
      {children}
    </FamilyShell>
  );
}
