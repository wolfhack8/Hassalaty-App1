import { Users, Star, Clock, Gift } from "lucide-react";
import { setRequestLocale } from "next-intl/server";
import { requireParent } from "@/server/family/require-family";
import { getFamilyOverview } from "@/server/family/get-family-context";
import { PageTitle, StatTile, Panel, Empty } from "@/features/admin/ui";
import { Link } from "@/i18n/routing";
import { pick } from "@/lib/localized";
import { formatCurrency } from "@/lib/format";
import type { Locale } from "@/i18n/routing";

export const dynamic = "force-dynamic";

export default async function ParentOverviewPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale);
  const lo = locale as Locale;
  const parent = await requireParent(locale);

  const overview = await getFamilyOverview(parent.familyId);
  if (!overview) return null;

  const totalPoints = overview.children.reduce((s, c) => s + c.points, 0);
  const totalPending = overview.children.reduce((s, c) => s + c.pendingRedemptions, 0);
  const totalWeekSpend = overview.children.reduce((s, c) => s + c.weekSpend, 0);

  return (
    <div>
      <PageTitle
        title={lo === "ar" ? "نظرة عامة على العائلة" : "Family overview"}
        subtitle={
          lo === "ar"
            ? "نقاط، إنفاق وطلبات مكافآت أبنائك في لمحة."
            : "Your children's points, spending and reward requests at a glance."
        }
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatTile label={lo === "ar" ? "الأبناء" : "Children"} value={overview.children.length} icon={<Users className="h-4 w-4" />} />
        <StatTile label={lo === "ar" ? "إجمالي النقاط" : "Total points"} value={totalPoints} icon={<Star className="h-4 w-4" />} />
        <StatTile
          label={lo === "ar" ? "إنفاق الأسبوع" : "This week's spend"}
          value={formatCurrency(totalWeekSpend, lo, { compact: true })}
          icon={<Clock className="h-4 w-4" />}
        />
        <StatTile label={lo === "ar" ? "طلبات مكافآت معلّقة" : "Pending reward requests"} value={totalPending} icon={<Gift className="h-4 w-4" />} />
      </div>

      <div className="mt-6">
        <Panel title={lo === "ar" ? "الأبناء" : "Children"}>
          {overview.children.length === 0 ? (
            <Empty>{lo === "ar" ? "لا يوجد أبناء مضافون بعد." : "No children added yet."}</Empty>
          ) : (
            <table className="w-full min-w-[560px] text-sm">
              <thead>
                <tr className="border-b border-border text-xs text-subtle-foreground">
                  <th className="px-5 py-2.5 text-start font-medium">{lo === "ar" ? "الابن" : "Child"}</th>
                  <th className="px-5 py-2.5 text-end font-medium">{lo === "ar" ? "النقاط" : "Points"}</th>
                  <th className="px-5 py-2.5 text-end font-medium">{lo === "ar" ? "إنفاق الأسبوع" : "Week spend"}</th>
                  <th className="px-5 py-2.5 text-end font-medium">{lo === "ar" ? "مكافآت معلّقة" : "Pending"}</th>
                </tr>
              </thead>
              <tbody>
                {overview.children.map((c) => (
                  <tr key={c.userId} className="border-b border-border/60 last:border-0">
                    <td className="px-5 py-2.5">
                      <Link href={`/parent/children/${c.userId}`} className="font-medium text-foreground hover:underline">
                        {pick(c.name, lo)}
                      </Link>
                      {c.activeChallenge && (
                        <p className="text-xs text-muted-foreground">
                          {lo === "ar" ? "تحدٍ نشط: " : "Active challenge: "}
                          {c.activeChallenge.title}
                        </p>
                      )}
                    </td>
                    <td className="px-5 py-2.5 text-end tnum font-medium text-foreground">{c.points}</td>
                    <td className="px-5 py-2.5 text-end tnum text-muted-foreground">
                      {formatCurrency(c.weekSpend, lo, { decimals: 0 })}
                    </td>
                    <td className="px-5 py-2.5 text-end tnum text-muted-foreground">
                      {c.pendingRedemptions > 0 ? c.pendingRedemptions : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Panel>
      </div>
    </div>
  );
}
