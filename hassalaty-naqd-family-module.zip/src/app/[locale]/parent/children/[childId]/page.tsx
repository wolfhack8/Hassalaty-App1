import { notFound } from "next/navigation";
import { Star, Wallet, Receipt } from "lucide-react";
import { setRequestLocale } from "next-intl/server";
import { requireParent, assertChildInFamily } from "@/server/family/require-family";
import { getChildSpendingSummary, categoryLabel } from "@/server/family/get-family-context";
import { listParentInsights } from "@/server/family/parent-insights";
import { ChildDetailProvider } from "@/features/family/child-detail-provider";
import { ParentInsightsPanel } from "@/features/family/parent-insights-panel";
import { PageTitle, StatTile, Panel, Empty } from "@/features/admin/ui";
import { pick } from "@/lib/localized";
import { formatCurrency } from "@/lib/format";
import type { Locale } from "@/i18n/routing";

export const dynamic = "force-dynamic";

export default async function ChildDetailPage({
  params,
}: {
  params: Promise<{ locale: string; childId: string }>;
}) {
  const { locale, childId } = await params;
  setRequestLocale(locale);
  const lo = locale as Locale;
  const parent = await requireParent(locale);

  const inFamily = await assertChildInFamily(parent.familyId, childId);
  if (!inFamily) notFound();

  const summary = await getChildSpendingSummary(childId, 7);
  if (!summary) notFound();

  const insights = await listParentInsights(childId);
  const childName = pick(summary.name, lo);

  return (
    <ChildDetailProvider childId={childId} childName={childName} locale={lo} summary={summary} initialInsights={insights}>
      <PageTitle
        title={childName}
        subtitle={lo === "ar" ? "آخر 7 أيام من نشاطه المالي في حصالته." : "Their last 7 days of activity in Hassalaty."}
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatTile label={lo === "ar" ? "النقاط" : "Points"} value={summary.points} icon={<Star className="h-4 w-4" />} />
        <StatTile
          label={lo === "ar" ? "إنفاق الأسبوع" : "Week spend"}
          value={formatCurrency(summary.totalSpend, lo, { decimals: 0 })}
          icon={<Wallet className="h-4 w-4" />}
        />
        <StatTile
          label={lo === "ar" ? "عدد المعاملات" : "Transactions"}
          value={summary.transactionCount}
          icon={<Receipt className="h-4 w-4" />}
        />
        <StatTile
          label={lo === "ar" ? "الفئة الأعلى" : "Top category"}
          value={summary.topCategory ? `${categoryLabel(summary.topCategory.category, lo)} · ${summary.topCategory.percentage}%` : "—"}
        />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <ParentInsightsPanel />

        <Panel title={lo === "ar" ? "المعاملات الأخيرة" : "Recent transactions"}>
          {summary.recentTransactions.length === 0 ? (
            <Empty>{lo === "ar" ? "لا توجد معاملات هذا الأسبوع." : "No transactions this week."}</Empty>
          ) : (
            <ul className="divide-y divide-border/60">
              {summary.recentTransactions.map((t, i) => (
                <li key={i} className="flex items-center justify-between px-5 py-2.5 text-sm">
                  <div>
                    <p className="font-medium text-foreground">{t.merchant}</p>
                    <p className="text-xs text-muted-foreground">{categoryLabel(t.category, lo)}</p>
                  </div>
                  <span className={t.amount < 0 ? "text-negative" : "text-positive"}>
                    {formatCurrency(t.amount, lo, { decimals: 0 })}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </ChildDetailProvider>
  );
}
