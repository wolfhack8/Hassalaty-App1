import type { Metadata } from "next";
import { setRequestLocale, getTranslations } from "next-intl/server";
import { AuthScreen } from "@/features/auth/auth-screen";

export async function generateMetadata(): Promise<Metadata> {
  const t = await getTranslations("auth");
  return { title: t("signIn") };
}

export default async function LoginPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale);
  // Only advertise a social button once *both* of that provider's env vars
  // are actually set (mirrors the same check `authProviders()` in
  // `lib/auth/providers.ts` uses to register the provider) — otherwise
  // clicking it would hit a provider NextAuth never registered.
  const socialProviders = {
    google: !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET),
    apple: !!(process.env.APPLE_CLIENT_ID && process.env.APPLE_CLIENT_SECRET),
  };
  return <AuthScreen mode="login" socialProviders={socialProviders} />;
}
