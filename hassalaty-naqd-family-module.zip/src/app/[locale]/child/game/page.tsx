import { setRequestLocale } from "next-intl/server";
import { requireChild } from "@/server/family/require-family";
import { CoinCatchGame } from "@/features/family/coin-catch-game";

export const dynamic = "force-dynamic";

export default async function ChildGamePage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  await requireChild(locale);

  return (
    <div className="mx-auto max-w-xl">
      <CoinCatchGame />
    </div>
  );
}
