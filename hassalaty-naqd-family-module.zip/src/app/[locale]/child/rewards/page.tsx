import { setRequestLocale } from "next-intl/server";
import { requireChild } from "@/server/family/require-family";
import { listRewards, listMyRedemptions, ensureDefaultRewards } from "@/server/family/reward-actions";
import { RewardStore, type RewardRow, type RedemptionRow } from "@/features/family/reward-store";
import { type Localized } from "@/lib/localized";

export const dynamic = "force-dynamic";

function asLocalized(value: unknown, fallback: Localized): Localized {
  if (value && typeof value === "object" && "en" in value && "ar" in value) return value as Localized;
  return fallback;
}

export default async function ChildRewardsPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const child = await requireChild(locale);

  await ensureDefaultRewards();
  const [rewards, redemptions] = await Promise.all([listRewards(child.familyId), listMyRedemptions(child.userId)]);

  const rewardRows: RewardRow[] = rewards.map((r) => ({
    id: r.id,
    title: asLocalized(r.title, { en: r.id, ar: r.id }),
    description: r.description ? asLocalized(r.description, { en: "", ar: "" }) : null,
    pointsCost: r.pointsCost,
    kind: r.kind,
  }));

  const redemptionRows: RedemptionRow[] = redemptions.map((r) => ({
    id: r.id,
    rewardId: r.rewardId,
    pointsCost: r.pointsCost,
    status: r.status,
    requestedAt: r.requestedAt.toISOString(),
    reward: { title: asLocalized(r.reward.title, { en: "Reward", ar: "مكافأة" }) },
  }));

  return <RewardStore initialRewards={rewardRows} initialRedemptions={redemptionRows} />;
}
