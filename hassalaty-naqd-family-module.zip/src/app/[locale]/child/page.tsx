import Link from "next/link";
import { Gamepad2, Gift, Receipt } from "lucide-react";
import { setRequestLocale } from "next-intl/server";
import { requireChild } from "@/server/family/require-family";
import { getChildSpendingSummary, categoryLabel } from "@/server/family/get-family-context";
import { ChildHomeGreeting, ChildActiveChallenge } from "@/features/family/child-home-widgets";
import { Card } from "@/components/ui/card";
import { formatCurrency } from "@/lib/format";
import type { Locale } from "@/i18n/routing";

export const dynamic = "force-dynamic";

const COPY = {
  en: {
    playGame: "Play & earn",
    playDesc: "Catch coins for points",
    rewards: "Rewards store",
    rewardsDesc: "Spend your points",
    recent: "Recent activity",
    empty: "No purchases yet this week.",
  },
  ar: {
    playGame: "العب واكسب",
    playDesc: "اجمع العملات لتربح نقاط",
    rewards: "متجر المكافآت",
    rewardsDesc: "استبدل نقاطك",
    recent: "آخر الحركات",
    empty: "لا توجد مشتريات هذا الأسبوع بعد.",
  },
} as const;

export default async function ChildHomePage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  setRequestLocale(locale);
  const lo = locale as Locale;
  const t = COPY[lo];
  const child = await requireChild(locale);
  const summary = await getChildSpendingSummary(child.userId, 7);

  return (
    <div>
      <ChildHomeGreeting />

      <div className="grid gap-4 sm:grid-cols-2">
        <Link href="/child/game">
          <Card className="flex items-center gap-3 p-5 transition-transform hover:-translate-y-0.5">
            <span className="grid h-12 w-12 place-items-center rounded-2xl bg-brand-soft text-primary-strong">
              <Gamepad2 className="h-5 w-5" />
            </span>
            <div>
              <p className="text-sm font-semibold text-foreground">{t.playGame}</p>
              <p className="text-xs text-muted-foreground">{t.playDesc}</p>
            </div>
          </Card>
        </Link>
        <Link href="/child/rewards">
          <Card className="flex items-center gap-3 p-5 transition-transform hover:-translate-y-0.5">
            <span className="grid h-12 w-12 place-items-center rounded-2xl bg-warning-soft text-warning">
              <Gift className="h-5 w-5" />
            </span>
            <div>
              <p className="text-sm font-semibold text-foreground">{t.rewards}</p>
              <p className="text-xs text-muted-foreground">{t.rewardsDesc}</p>
            </div>
          </Card>
        </Link>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <ChildActiveChallenge />

        <Card className="p-5">
          <p className="flex items-center gap-2 text-sm font-semibold text-foreground">
            <Receipt className="h-4 w-4 text-muted-foreground" />
            {t.recent}
          </p>
          {!summary || summary.recentTransactions.length === 0 ? (
            <p className="mt-3 text-sm text-muted-foreground">{t.empty}</p>
          ) : (
            <ul className="mt-2 divide-y divide-border/60">
              {summary.recentTransactions.slice(0, 5).map((tx, i) => (
                <li key={i} className="flex items-center justify-between py-2 text-sm">
                  <div>
                    <p className="font-medium text-foreground">{tx.merchant}</p>
                    <p className="text-xs text-muted-foreground">{categoryLabel(tx.category, lo)}</p>
                  </div>
                  <span className={tx.amount < 0 ? "text-negative" : "text-positive"}>
                    {formatCurrency(tx.amount, lo, { decimals: 0 })}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
