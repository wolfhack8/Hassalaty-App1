import type { Metadata } from "next";
import { setRequestLocale } from "next-intl/server";
import { prisma } from "@/lib/db";
import { pick, loc, type Localized } from "@/lib/localized";
import type { Locale } from "@/i18n/routing";
import { requireChild } from "@/server/family/require-family";
import { getActiveChallenge } from "@/server/family/weekly-challenge";
import { FamilyShell } from "@/features/family/family-shell";
import { ChildHomeProvider } from "@/features/family/child-home-provider";
import { KidAssistantWidget } from "@/features/family/kid-assistant-widget";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "My Hassalaty",
  robots: { index: false, follow: false },
};

function asLocalized(value: unknown, fallback: Localized): Localized {
  if (value && typeof value === "object" && "en" in value && "ar" in value) {
    return value as Localized;
  }
  return fallback;
}

export default async function ChildLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale);
  const lo = locale as Locale;
  const child = await requireChild(locale);

  const [membership, challenge] = await Promise.all([
    prisma.familyMembership.findUnique({
      where: { userId: child.userId },
      select: {
        points: true,
        user: { select: { firstName: true } },
        family: { select: { name: true } },
      },
    }),
    getActiveChallenge(child.userId),
  ]);

  const firstName = pick(asLocalized(membership?.user.firstName, loc("friend", "صديقي")), lo);
  const familyName = pick(asLocalized(membership?.family.name, loc("Hassalaty", "حصالتي")), lo);

  return (
    <ChildHomeProvider
      locale={lo}
      firstName={firstName}
      familyName={familyName}
      initialPoints={membership?.points ?? 0}
      initialChallenge={challenge}
    >
      <FamilyShell variant="child" title={familyName} subtitle={firstName || undefined}>
        {children}
      </FamilyShell>
      <KidAssistantWidget />
    </ChildHomeProvider>
  );
}
