import { systemPrompt } from "./financial-context";
import { scriptedReply } from "./scripted";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { getFinanceContext } from "@/server/finance/get-finance-context";
import { getDashboardOrg } from "@/server/company/get-company-context";
import { logActivity } from "@/server/admin/audit";
import { streamWithFallbackChain, type ChatMessage } from "@/server/ai/openrouter";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Derive a short conversation title from the first user message. */
function deriveTitle(text: string): string {
  const t = text.replace(/\s+/g, " ").trim();
  if (!t) return "New chat";
  return t.length > 48 ? `${t.slice(0, 48).trimEnd()}…` : t;
}

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user?.id) {
    return new Response("Unauthorized", { status: 401 });
  }
  const userId = session.user.id;

  const finance = await getFinanceContext(userId);
  if (!finance) {
    return new Response("Unauthorized", { status: 401 });
  }

  // Resolve company role/membership from the DB (confidentiality boundary — not
  // the JWT). Owners get the employee snapshot injected; employees get none.
  const org = await getDashboardOrg(userId);

  let body: { messages?: ChatMessage[]; locale?: string; conversationId?: string };
  try {
    body = await req.json();
  } catch {
    return new Response("Bad request", { status: 400 });
  }

  const messages = (body.messages ?? []).filter(
    (m) => m.role === "user" || m.role === "assistant",
  );
  const locale: "en" | "ar" = body.locale === "ar" ? "ar" : "en";
  const lastUser = [...messages].reverse().find((m) => m.role === "user")?.content ?? "";
  if (!lastUser.trim()) {
    return new Response("Bad request", { status: 400 });
  }

  // Resolve or create the conversation, then persist the incoming user message.
  let conversationId = body.conversationId;
  if (conversationId) {
    const owned = await prisma.conversation.findFirst({
      where: { id: conversationId, userId },
      select: { id: true },
    });
    if (!owned) conversationId = undefined;
  }
  if (!conversationId) {
    const created = await prisma.conversation.create({
      data: { userId, title: deriveTitle(lastUser) },
      select: { id: true },
    });
    conversationId = created.id;
  }
  await prisma.chatMessage.create({
    data: { conversationId, role: "user", content: lastUser },
  });
  await logActivity({
    action: "assistant.message",
    userId,
    email: session.user.email ?? null,
    detail: lastUser.length > 80 ? `${lastUser.slice(0, 80)}…` : lastUser,
    req,
  });

  const system = systemPrompt(locale, finance, org);
  const convoId = conversationId;

  const parts: string[] = [];
  const stream = new ReadableStream({
    async start(controller) {
      try {
        await streamWithFallbackChain(controller, parts, messages, system, scriptedReply(lastUser, locale));
      } finally {
        controller.close();
        const answer = parts.join("").trim();
        if (answer) {
          try {
            await prisma.chatMessage.create({
              data: { conversationId: convoId, role: "assistant", content: answer },
            });
            await prisma.conversation.update({
              where: { id: convoId },
              data: { updatedAt: new Date() },
            });
          } catch {
            /* persistence best-effort */
          }
        }
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-cache",
      "X-Conversation-Id": convoId ?? "",
    },
  });
}
