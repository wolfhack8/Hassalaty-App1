import { NextResponse } from "next/server";
import { getParent, assertChildInFamily } from "@/server/family/require-family";
import { generateParentInsight, listParentInsights } from "@/server/family/parent-insights";
import { logActivity } from "@/server/admin/audit";
import type { InsightPeriod } from "@prisma/client";

/** Parent-only: list saved insight reports for one of their children. */
export async function GET(req: Request) {
  const parent = await getParent();
  if (!parent) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const childId = new URL(req.url).searchParams.get("childId");
  if (!childId) {
    return NextResponse.json({ error: "Missing childId" }, { status: 400 });
  }
  const inFamily = await assertChildInFamily(parent.familyId, childId);
  if (!inFamily) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const reports = await listParentInsights(childId);
  return NextResponse.json({ ok: true, reports });
}

/** Parent-only: generate (AI, with a rule-based fallback) a fresh insight report. */
export async function POST(req: Request) {
  const parent = await getParent();
  if (!parent) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  let body: { childId?: string; locale?: string; period?: InsightPeriod };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const childId = body.childId;
  if (!childId) {
    return NextResponse.json({ error: "Missing childId" }, { status: 400 });
  }
  const inFamily = await assertChildInFamily(parent.familyId, childId);
  if (!inFamily) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const locale = body.locale === "ar" ? "ar" : "en";
  const period: InsightPeriod = body.period === "MONTHLY" ? "MONTHLY" : "WEEKLY";

  const result = await generateParentInsight({
    parentUserId: parent.userId,
    childUserId: childId,
    locale,
    period,
  });

  if ("error" in result) {
    return NextResponse.json({ error: result.error }, { status: 404 });
  }

  await logActivity({
    action: "family.insight.generate",
    userId: parent.userId,
    email: parent.email,
    detail: `Generated ${period.toLowerCase()} insight for child ${childId}`,
    req,
  });

  return NextResponse.json({ ok: true, report: result });
}
