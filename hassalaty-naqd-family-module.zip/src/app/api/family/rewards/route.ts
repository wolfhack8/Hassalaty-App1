import { NextResponse } from "next/server";
import { getParent, getChild } from "@/server/family/require-family";
import { listRewards, listMyRedemptions, createFamilyReward, ensureDefaultRewards } from "@/server/family/reward-actions";
import { logActivity } from "@/server/admin/audit";

/** Either role: list the family's reward catalog (global + family-specific).
 *  A CHILD additionally gets their own redemption history alongside it. */
export async function GET() {
  const parent = await getParent();
  const child = parent ? null : await getChild();
  const familyId = parent?.familyId ?? child?.familyId;
  if (!familyId) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  await ensureDefaultRewards();
  const rewards = await listRewards(familyId);
  const myRedemptions = child ? await listMyRedemptions(child.userId) : [];
  return NextResponse.json({ ok: true, rewards, myRedemptions });
}

/** Parent-only: add a custom, pre-approved reward to the family catalog. */
export async function POST(req: Request) {
  const parent = await getParent();
  if (!parent) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  let body: {
    title?: string;
    titleAr?: string;
    description?: string;
    descriptionAr?: string;
    pointsCost?: number;
    kind?: "DIGITAL_THEME" | "REAL_WORLD";
  };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const title = body.title?.trim();
  const pointsCost = Number(body.pointsCost);
  if (!title || !Number.isFinite(pointsCost) || pointsCost <= 0) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }

  const reward = await createFamilyReward({
    familyId: parent.familyId,
    title,
    titleAr: body.titleAr,
    description: body.description,
    descriptionAr: body.descriptionAr,
    pointsCost,
    kind: body.kind === "REAL_WORLD" ? "REAL_WORLD" : "DIGITAL_THEME",
  });

  await logActivity({
    action: "family.reward.create",
    userId: parent.userId,
    email: parent.email,
    detail: `Added reward "${title}" (${pointsCost} pts)`,
    req,
  });

  return NextResponse.json({ ok: true, reward });
}
