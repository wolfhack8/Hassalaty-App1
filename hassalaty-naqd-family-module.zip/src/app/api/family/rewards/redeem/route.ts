import { NextResponse } from "next/server";
import { getChild } from "@/server/family/require-family";
import { redeemReward } from "@/server/family/reward-actions";
import { logActivity } from "@/server/admin/audit";

/** Child-only: spend points on a reward. Creates a PENDING request for the
 *  parent to approve or reject; points are held (debited) immediately so
 *  they can't be double-spent while a request is pending. */
export async function POST(req: Request) {
  const child = await getChild();
  if (!child) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  let body: { rewardId?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }
  if (!body.rewardId) {
    return NextResponse.json({ error: "Missing rewardId" }, { status: 400 });
  }

  const result = await redeemReward(child.userId, body.rewardId);
  if (!result.ok) {
    return NextResponse.json({ error: result.error }, { status: 400 });
  }

  await logActivity({
    action: "family.reward.redeem",
    userId: child.userId,
    email: child.email,
    detail: `Requested reward ${body.rewardId}`,
    req,
  });

  return NextResponse.json({
    ok: true,
    redemptionId: result.redemptionId,
    remainingPoints: result.remainingPoints,
  });
}
