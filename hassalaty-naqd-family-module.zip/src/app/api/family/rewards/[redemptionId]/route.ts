import { NextResponse } from "next/server";
import { getParent } from "@/server/family/require-family";
import { resolveRedemption } from "@/server/family/reward-actions";
import { logActivity } from "@/server/admin/audit";

/** Parent-only: approve or reject a pending redemption from one of their children. */
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ redemptionId: string }> },
) {
  const parent = await getParent();
  if (!parent) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  const { redemptionId } = await params;

  let body: { approve?: boolean };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const result = await resolveRedemption(parent.userId, parent.familyId, redemptionId, !!body.approve);
  if (!result.ok) {
    return NextResponse.json({ error: result.error }, { status: 404 });
  }

  await logActivity({
    action: "family.reward.resolve",
    userId: parent.userId,
    email: parent.email,
    detail: `${body.approve ? "Approved" : "Rejected"} redemption ${redemptionId}`,
    req,
  });

  return NextResponse.json({ ok: true, status: result.status, refundedPoints: result.refundedPoints });
}
