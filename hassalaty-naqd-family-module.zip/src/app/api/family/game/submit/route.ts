import { NextResponse } from "next/server";
import { getChild } from "@/server/family/require-family";
import { submitGameSession } from "@/server/family/game-actions";
import { logActivity } from "@/server/admin/audit";
import { GameType } from "@prisma/client";

/** Child-only: submit a finished mini-game round. The server computes
 *  points from the raw score/duration (see `submitGameSession`) — the
 *  client never sends a points number directly. */
export async function POST(req: Request) {
  const child = await getChild();
  if (!child) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  let body: { gameType?: string; score?: number; durationMs?: number };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }

  const gameType = body.gameType === "TRIVIA" ? GameType.TRIVIA : GameType.COIN_CATCH;
  const score = Number(body.score);
  const durationMs = Number(body.durationMs);

  const result = await submitGameSession({ userId: child.userId, gameType, score, durationMs });
  if (!result.ok) {
    return NextResponse.json({ error: result.error }, { status: 400 });
  }

  await logActivity({
    action: "family.game.submit",
    userId: child.userId,
    email: child.email,
    detail: `${gameType} score ${score} → +${result.pointsEarned} points`,
    req,
  });

  return NextResponse.json({
    ok: true,
    pointsEarned: result.pointsEarned,
    totalPoints: result.totalPoints,
    cappedByDailyLimit: result.cappedByDailyLimit,
  });
}
