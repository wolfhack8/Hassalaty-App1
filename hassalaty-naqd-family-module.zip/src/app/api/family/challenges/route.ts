import { NextResponse } from "next/server";
import { getParent, getChild, assertChildInFamily } from "@/server/family/require-family";
import { generateWeeklyChallenge, getActiveChallenge } from "@/server/family/weekly-challenge";
import { logActivity } from "@/server/admin/audit";

/** Child: their own active challenge. Parent: a specific child's, via ?childId=. */
export async function GET(req: Request) {
  const child = await getChild();
  if (child) {
    const challenge = await getActiveChallenge(child.userId);
    return NextResponse.json({ ok: true, challenge });
  }

  const parent = await getParent();
  if (!parent) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  const childId = new URL(req.url).searchParams.get("childId");
  if (!childId || !(await assertChildInFamily(parent.familyId, childId))) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  const challenge = await getActiveChallenge(childId);
  return NextResponse.json({ ok: true, challenge });
}

/** Parent-only: AI-generate (with a rule-based fallback) this week's challenge for a child. */
export async function POST(req: Request) {
  const parent = await getParent();
  if (!parent) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  let body: { childId?: string; locale?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Bad request" }, { status: 400 });
  }
  const childId = body.childId;
  if (!childId || !(await assertChildInFamily(parent.familyId, childId))) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const locale = body.locale === "ar" ? "ar" : "en";
  const result = await generateWeeklyChallenge({ childUserId: childId, locale });
  if ("error" in result) {
    return NextResponse.json({ error: result.error }, { status: 404 });
  }

  await logActivity({
    action: "family.challenge.generate",
    userId: parent.userId,
    email: parent.email,
    detail: `Generated challenge "${result.title}" for child ${childId}`,
    req,
  });

  return NextResponse.json({ ok: true, challenge: result });
}
