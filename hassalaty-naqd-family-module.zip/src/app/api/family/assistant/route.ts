import { prisma } from "@/lib/db";
import { getChild } from "@/server/family/require-family";
import { getChildSpendingSummary } from "@/server/family/get-family-context";
import { kidAssistantSystemPrompt, kidScriptedReply } from "@/server/family/kid-assistant";
import { streamWithFallbackChain, type ChatMessage } from "@/server/ai/openrouter";
import { logActivity } from "@/server/admin/audit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function deriveTitle(text: string): string {
  const t = text.replace(/\s+/g, " ").trim();
  if (!t) return "New chat";
  return t.length > 48 ? `${t.slice(0, 48).trimEnd()}…` : t;
}

/**
 * Streaming chat for the CHILD-facing "Hassalaty AI" assistant. Structurally
 * identical to `app/api/chat/route.ts` (same conversation persistence, same
 * `streamWithFallbackChain` primitive) but grounded in the child's own
 * points/spending snapshot and using the kid-safe system prompt + scripted
 * fallback from `server/family/kid-assistant.ts`.
 */
export async function POST(req: Request) {
  const child = await getChild();
  if (!child) {
    return new Response("Unauthorized", { status: 401 });
  }

  const [membership, summary] = await Promise.all([
    prisma.familyMembership.findUnique({ where: { userId: child.userId }, select: { points: true } }),
    getChildSpendingSummary(child.userId, 7),
  ]);
  if (!membership || !summary) {
    return new Response("Unauthorized", { status: 401 });
  }

  let body: { messages?: ChatMessage[]; locale?: string; conversationId?: string };
  try {
    body = await req.json();
  } catch {
    return new Response("Bad request", { status: 400 });
  }

  const messages = (body.messages ?? []).filter((m) => m.role === "user" || m.role === "assistant");
  const locale: "en" | "ar" = body.locale === "ar" ? "ar" : "en";
  const lastUser = [...messages].reverse().find((m) => m.role === "user")?.content ?? "";
  if (!lastUser.trim()) {
    return new Response("Bad request", { status: 400 });
  }

  let conversationId = body.conversationId;
  if (conversationId) {
    const owned = await prisma.conversation.findFirst({
      where: { id: conversationId, userId: child.userId },
      select: { id: true },
    });
    if (!owned) conversationId = undefined;
  }
  if (!conversationId) {
    const created = await prisma.conversation.create({
      data: { userId: child.userId, title: deriveTitle(lastUser) },
      select: { id: true },
    });
    conversationId = created.id;
  }
  await prisma.chatMessage.create({ data: { conversationId, role: "user", content: lastUser } });
  await logActivity({
    action: "family.assistant.message",
    userId: child.userId,
    email: child.email,
    detail: lastUser.length > 80 ? `${lastUser.slice(0, 80)}…` : lastUser,
    req,
  });

  const kidCtx = { firstName: child.email.split("@")[0] ?? "friend", points: membership.points, spending: summary };
  const system = kidAssistantSystemPrompt(locale, kidCtx);
  const offlineText = kidScriptedReply(lastUser, locale, kidCtx);
  const convoId = conversationId;

  const parts: string[] = [];
  const stream = new ReadableStream({
    async start(controller) {
      try {
        await streamWithFallbackChain(controller, parts, messages, system, offlineText);
      } finally {
        controller.close();
        const answer = parts.join("").trim();
        if (answer) {
          try {
            await prisma.chatMessage.create({
              data: { conversationId: convoId, role: "assistant", content: answer },
            });
            await prisma.conversation.update({ where: { id: convoId }, data: { updatedAt: new Date() } });
          } catch {
            /* persistence best-effort */
          }
        }
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-cache",
      "X-Conversation-Id": convoId ?? "",
    },
  });
}
