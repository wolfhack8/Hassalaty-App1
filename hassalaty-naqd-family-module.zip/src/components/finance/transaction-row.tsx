"use client";

import type { KeyboardEvent } from "react";
import { useLocale, useTranslations } from "next-intl";
import type { Locale } from "@/i18n/routing";
import type { Transaction } from "@/data/types";
import { categories } from "@/data/categories";
import { DynamicIcon } from "@/components/ui/dynamic-icon";
import { pick } from "@/lib/localized";
import { formatTime, formatDate } from "@/lib/format";
import { Money } from "@/components/ui/money";
import { cn } from "@/lib/utils";

export function TransactionRow({
  tx,
  showDate = false,
  className,
  onClick,
}: {
  tx: Transaction;
  showDate?: boolean;
  className?: string;
  /** When provided, the row becomes an interactive button that fires this. */
  onClick?: () => void;
}) {
  const locale = useLocale() as Locale;
  const t = useTranslations("transactions");
  const category = categories[tx.category];
  const income = tx.amount > 0;
  const interactive = Boolean(onClick);

  const methodLabel = {
    card: t("methodCard"),
    applepay: t("methodApplepay"),
    transfer: t("methodTransfer"),
    wallet: t("methodWallet"),
  }[tx.method];

  return (
    <div
      {...(interactive
        ? {
            role: "button" as const,
            tabIndex: 0,
            onClick,
            onKeyDown: (e: KeyboardEvent) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                onClick?.();
              }
            },
          }
        : {})}
      className={cn(
        "flex items-center gap-3 rounded-2xl px-2 py-2.5 transition-colors hover:bg-surface-muted",
        interactive &&
          "cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring",
        className,
      )}
    >
      <span
        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl"
        style={{ backgroundColor: `color-mix(in oklab, ${category.color} 14%, transparent)` }}
      >
        <DynamicIcon
          name={category.icon}
          className="h-[1.1rem] w-[1.1rem]"
          strokeWidth={2.1}
        />
      </span>

      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-foreground">
          {pick(tx.merchant, locale)}
        </p>
        <p className="truncate text-xs text-muted-foreground">
          {showDate
            ? formatDate(tx.date, locale, { day: "numeric", month: "short" })
            : tx.note
              ? pick(tx.note, locale)
              : methodLabel}
        </p>
      </div>

      <div className="text-end">
        <p
          className={cn(
            "text-sm font-semibold",
            income ? "text-positive" : "text-foreground",
          )}
        >
          <Money value={tx.amount} locale={locale} signed />
        </p>
        <p className="text-xs text-subtle-foreground tnum">
          {tx.status === "scheduled"
            ? t("statusScheduled")
            : formatTime(tx.date, locale)}
        </p>
      </div>
    </div>
  );
}
